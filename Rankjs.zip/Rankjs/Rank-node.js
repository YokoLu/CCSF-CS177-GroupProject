const express = require('express');
const cors = require('cors');
const app = express();

app.use(cors());
app.use(express.json());

// Track how many times each rating (1–10) was chosen
const ratingCounts = {
  1: 0, 2: 0, 3: 0, 4: 0, 5: 0,
  6: 0, 7: 0, 8: 0, 9: 0, 10: 0
};

app.post('/api/rank', (req, res) => {
  const { rating } = req.body;

  // Validate rating
  if (typeof rating !== 'number' || rating < 1 || rating > 10) {
    return res.status(400).json({ message: 'Rating must be a number between 1 and 10' });
  }

  // Count the rating
  ratingCounts[rating]++;
  console.log(`Received rating: ${rating}`);
  console.log('Rating counts:', ratingCounts);

  res.status(200).json({ message: 'Rating received. Thank you!', yourRating: rating });
});

app.get('/', (req, res) => {
  res.send('🎉 Welcome to the rating system. Please submit your rank.');
});

const PORT = 3001;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
