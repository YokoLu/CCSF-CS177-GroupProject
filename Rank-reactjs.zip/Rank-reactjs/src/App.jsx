import React from 'react';
import Rank from './Rank'; // or './rank-react' if you keep the old name

function App() {
  return (
    <div className="App">
      <Rank />
    </div>
  );
}

export default App;
